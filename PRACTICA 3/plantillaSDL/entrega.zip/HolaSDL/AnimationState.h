//#pragma once
//#include <functional>
//#include "GameState.h"
//#include "Player.h"
//class AnimationState : public GameState
//{
//private:
//    GameState* playState; 
//    std::function<bool()> animationCallback;
//
//public:
//    AnimationState(Game* g,GameState* state, std::function<bool()> callback) : playState(state), animationCallback(callback);
//
//    void update(float dt)const  ;
//
//    void render();
//};

