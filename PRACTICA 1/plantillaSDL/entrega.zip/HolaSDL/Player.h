#pragma once
#include "checkML.h"

#include <string>
#include <iostream>
#include <fstream>

#include "Texture.h"
#include "Game.h"
#include "Vector2D.h"

#include "Collision.h"

using namespace std;

class Game;

class Player
{
private:
	Texture* texture = nullptr;
	Texture* supertexture = nullptr;
	Game* game = nullptr;

	SDL_Rect rect;

	Point2D<int> pos;
	Point2D<int> initPos;
	Point2D<int> dir;
	int speed;

	int lives;

	enum Aspect {
		MARIO,
		SUPERMARIO
	};

	// 0: MARIO
	// 1: SUPERMARIO
	Aspect actualAspect;

	// cuando supermario sea golpeado inmune = true durante un par de segundos
	bool inmune;

	// --- para las animaciones
	// textura actual de mario
	int frame;
	// frame de andado 
	int walkFrame;
	// contador de frames
	int frameCounter;
	// true izquierda, false derecha
	bool flipSprite;

	// --- salto
	bool jumping;
	bool onGround;
    int jumpVelocity;
	int gravity;         
	int groundY;


	// --- DEBUGGING
	bool debugMode = false;
	bool fastMode = false;

public:
	Player();
	Player(Game* g, int x, int y);
	~Player();

	void render();
	void update();

	// movimiento intencionado
	void move();

	// pone la direccion en y a 1 hasta que llega a cierta altura
	void jump();

	// actualiza el frame de la textura
	void updateAnim();

	// cambia el aspecto a SUPERMARIO
	void grow();

	// reinicia el nivel
	void resetLevel();

	// maneja eventos de teclado y determina el estado del movimiento
	void handleEvents(const SDL_Event& event);

	/*
	detecta colisiones y recibe da�o
	MARIO colisiona con un enemigo o caiga 
	-> lives--
	-> volver� a su posici�n inicial en el nivel
	  SUPERMARIO al chocar con un enemigo 
	-> se convertir� en MARIO
	-> permanecer� donde est�
	-> se mantendr� invulnerable durante un par de segundos
	[ Cosas de Ruben ]
	Utiliza los m�todos SDL_HasIntersection o SDL_IntersectRect 
	con su caja de colisi�n y la que recibe para determinar si hay colisi�n.
	*/
	void hit();

	/// GETTERS --------------------------------
	// devuelve el numero de vidas actuales
	int getLives() const { return lives; }
	// devuelve el aspecto actual de mario
	Aspect getAspect() { return actualAspect; }

	// d = true: para mostrar en consola debugs y poder usar fastMode
	void debug();
};

